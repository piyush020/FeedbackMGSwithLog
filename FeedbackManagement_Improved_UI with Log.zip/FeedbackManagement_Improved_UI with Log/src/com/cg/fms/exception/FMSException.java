package com.cg.fms.exception;

public class FMSException extends Exception {

	String message;

	public FMSException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
