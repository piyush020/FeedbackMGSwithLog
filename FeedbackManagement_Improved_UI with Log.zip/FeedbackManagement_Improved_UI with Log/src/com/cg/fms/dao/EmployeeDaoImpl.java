package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;
import com.cg.fms.util.DBUtil;



public class EmployeeDaoImpl implements EmployeeDao{
	Connection con;
	 Logger empLogger= null;
	public EmployeeDaoImpl()
	
	{  
	empLogger= Logger.getLogger(Employee.class);
	    PropertyConfigurator.configure("log4j.properties");
		con = DBUtil.getConnection();
		
	}

	@Override
	public Employee getEmployeeById(int id) throws FMSException {
		// TODO Auto-generated method stub
		Employee ref = null;
		String qry = "SELECT * FROM employee_master WHERE employee_id=?";
		try
		{
	
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1,id);
			ResultSet rs = pstmt.executeQuery();
			empLogger.info("Get the Employee Details for the given EmployeeId");
			if(rs.next())
			{
				int empId = rs.getInt(1);
				String empName = rs.getString(2);
				String  empPass = rs.getString(3);
				String empRole = rs.getString(4);
				ref = new Employee(empId,empName,empPass,empRole);
				
			}
			
		}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		return ref;
	
	}

	@Override
	public ArrayList<Employee> getAllEmployees() throws FMSException {
		// TODO Auto-generated method stub
		String qry = "SELECT * FROM employee_master";
		ArrayList<Employee>list = new ArrayList<Employee>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			empLogger.info("Fetch All  Employee Details ");
			while(rs.next())
			{
				int empId = rs.getInt(1);
				String empName = rs.getString(2);
				String empPass= rs.getString(3);
				String empRole = rs.getString(4);
				Employee emp = new Employee(empId,empName,empPass,empRole);
				list.add(emp);
			}
		}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		return list;
	
	}

	@Override
	public Employee addEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		Employee ref = null;
		String qry = "INSERT INTO employee_master VALUES(?,?,?,?)";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, emp.getEmployeeId());
			pstmt.setString(2, emp.getEmployeeName());
			pstmt.setString(3, emp.getPassword());
			pstmt.setString(4, emp.getRole());
			int n= pstmt.executeUpdate();
			empLogger.info("Employee is added");
			if(n>0)
			{
				
				ref = emp;
			}
		}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		return ref;
		
	}

	@Override
	public Employee updateEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		String qry = "Update employee_master set employee_id=?, employee_name=?, password=?, role=? where employee_id=?";
		Employee ref = null;
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1,emp.getEmployeeId());
			pstmt.setString(2,emp.getEmployeeName() );
			pstmt.setString(3,emp.getPassword() );
			pstmt.setString(4,emp.getRole());
			int n = pstmt.executeUpdate();
			empLogger.info(" Employee Details updated");
			if(n>0)
			ref =emp; 
			
		}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		return ref;
	}

	@Override
	public boolean deleteEmployee(int id) throws FMSException {
		// TODO Auto-generated method stub
		int n=0;
		String qry="DELETE FROM  employee_master WHERE employee_id=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1,id);
			 n=pstmt.executeUpdate();
			 empLogger.info("Employee Detail is Deleted");
	}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		
		 if(n>0)
		return true;
		else
			return false;
	}

	@Override
	public Employee getEmployeeByName(String name) throws FMSException 
	{
		Employee ref = null;
		String qry = "SELECT * FROM employee_master WHERE employee_name=?";
		try
		{
	
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1,name);
			ResultSet rs = pstmt.executeQuery();
			empLogger.info("Get the Employee Details for the given EmployeeName");
			if(rs.next())
			{
				int empId = rs.getInt(1);
				String empName = rs.getString(2);
				String  empPass = rs.getString(3);
				String empRole = rs.getString(4);
				ref = new Employee(empId,empName,empPass,empRole);
				
			}
		}
		catch(Exception e)
		{
			throw new FMSException(e.getMessage());
		}
		return ref;
	}

}
