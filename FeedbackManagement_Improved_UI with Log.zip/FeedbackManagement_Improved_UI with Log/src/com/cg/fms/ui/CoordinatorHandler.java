package com.cg.fms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.ParticipantEnrollment;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.EmployeeService;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class CoordinatorHandler {

	Employee coordinator;
	static Scanner sc = new Scanner(System.in);
	static TrainingService trainingService = null;
	static ParticipantEnrollmentService participantService = null;
	static FeedbackService feedbackService = null;
	static EmployeeService employeeService = null;

	public CoordinatorHandler(Employee employee) {
		super();
		coordinator = employee;
		participantService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
		employeeService = new EmployeeServiceImpl();
	}

	public void start() throws FMSException {
		System.out.println("*****************************************");
		System.out.println("Welcome " + coordinator.getEmployeeName());
		while (true) {
			System.out.println("You are logged in as COORDINATOR");
			System.out.println("What do you want to do");
			System.out.println("1.Training program Maintenance\n" + "2.Participant Enrollment\n"
					+ "3.View Feedback Report\n" + "4.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				trainingProgramMaintenance();
				break;
			case 2:
				participantEnrollment();
				break;
			case 3:
				viewFeedbackReport();
				break;
			case 4:
				MainClass.main(null);
				break;

			default:
				break;

			}
		}
	}

	private void viewFeedbackReport() throws FMSException {
		while (true) {
			System.out.println("\nNow you are in Feedback Report Page");
			System.out.println(
					"1.View Feedback for All Training Programs\n2.Average Feedback For Selected Month\n3.Facultywise Feedback\n4.Feedback Defaulters Details\n5.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				viewFeedBack();
				break;
			case 2:
				AverageFeedback();
				break;
			case 3:
				facultyWiseAverageFeedback();
				break;
			case 4:
				feedbackDefaulters();
				break;
			case 5:
				start();
				break;
			default:
				break;

			}
		}

	}

	private void feedbackDefaulters() throws FMSException {
		System.out.println("Enter a Month");
		int month = sc.nextInt();
		if (month <= 12) {
			ArrayList feedback = feedbackService.defaultersFeedback(month);
			if (feedback.size() > 0) {
				Iterator it = feedback.iterator();
				while (it.hasNext()) {
					System.out.println(it.next());
				}
			} else
				System.out.println("No record found for this month");
		} else
			System.out.println("Enter the Valid Month");
	}

	private void facultyWiseAverageFeedback() throws FMSException {

		System.out.println("Enter a Faculty Code");
		int fc = sc.nextInt();
		if (employeeService.validateId(fc)) {
			if (employeeService.getEmployeeById(fc).getRole().equalsIgnoreCase("trainer")) {
				System.out.println("Enter a Month");
				int month = sc.nextInt();
				if (month <= 12) {
					ArrayList feedback = feedbackService.facultyFeedback(fc, month);

					int presentation = 0;
					int clarifyDoubts = 0;
					int timeMgt = 0;
					int hwAndSw = 0;
					int handOut = 0;
					if (feedback != null && feedback.size() > 0) {
						for (int i = 2; i <= feedback.size(); i = i + 7) {
							presentation = presentation + (int) feedback.get(i);
							clarifyDoubts = clarifyDoubts + (int) feedback.get(i + 1);
							timeMgt = timeMgt + (int) feedback.get(i + 2);
							handOut = handOut + (int) feedback.get(i + 3);
							hwAndSw = hwAndSw + (int) feedback.get(i + 4);

						}
						int size = feedback.size() / 8;
						// int size = feedback.size();
						System.out.println(size);
						System.out.println("Average score for presentation :" + presentation / size);
						System.out.println("Average score for Clarify Doubts :" + clarifyDoubts / size);
						System.out.println("Average score for Time Management :" + timeMgt / size);
						System.out.println("Average score for HandOut :" + handOut / size);
						System.out.println("Average score for Hardware and Software : " + hwAndSw / size);
					} else
						System.out.println("No record found for this month");
				} else
					System.out.println("Enter a valid Month");
			} else
				System.out.println("Faculty Code does not exist.");
		} else
			System.out.println("Faculty Code not valid.");
	}

	private void AverageFeedback() throws FMSException {
		System.out.println("Enter a Month");
		int month = sc.nextInt();
		if (month <= 12) {
			ArrayList feedback = feedbackService.joinTrainingWithFeed(month);
			// System.out.println(feedback);
			int presentation = 0;
			int clarifyDoubts = 0;
			int timeMgt = 0;
			int hwAndSw = 0;
			int handOut = 0;

			for (int i = 3; i <= feedback.size(); i = i + 8) {
				presentation = presentation + (int) feedback.get(i);
				clarifyDoubts = clarifyDoubts + (int) feedback.get(i + 1);
				timeMgt = timeMgt + (int) feedback.get(i + 2);
				handOut = handOut + (int) feedback.get(i + 3);
				hwAndSw = hwAndSw + (int) feedback.get(i + 4);

			}
			int size = feedback.size() / 8;
			System.out.println("Average score for presentation :" + presentation / size);
			System.out.println("Average score for Clarify Doubts :" + clarifyDoubts / size);
			System.out.println("Average score for Time Management :" + timeMgt / size);
			System.out.println("Average score for HandOut :" + handOut / size);
			System.out.println("Average score for Hardware and Software : " + hwAndSw / size);
		} else
			System.out.println("Enter a valid Month");
	}

	private void viewFeedBack() throws FMSException {

		ArrayList<Feedback> feedback = feedbackService.getAllFeedbacks();
		Iterator<Feedback> it = feedback.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

	}

	private void participantEnrollment() throws FMSException {
		while (true) {
			System.out.println("\nNow you are in the Participant Enrollment");
			System.out.println(
					"1.Add Participant Enrollment\n2.Participant Enrollment by ParticipantId\n3.Participant Enrollment by TrainingId\n4.View All Participant Enrollments\n5.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				addParticipantEnrollment();
				break;
			case 2:
				searchByParticipantId();
				break;
			case 3:
				searchByTrainingId();
				break;
			case 4:
				viewParticipantEnrollment();
				break;
			case 5:
				start();
				break;
			default:
				break;
			}
		}

	}

	private void viewParticipantEnrollment() {
		System.out.println("View Paricipant Enrollments");
		try {
			ArrayList<ParticipantEnrollment> partEnroll = participantService.getAllParticipantEnrollments();
			Iterator<ParticipantEnrollment> it = partEnroll.iterator();
			while (it.hasNext()) {
				System.out.println(it.next());
			}

		} catch (FMSException e) {

			e.printStackTrace();
		}

	}

	private void searchByTrainingId() throws FMSException {
		System.out.println("Enter Training Id");
		int tc = sc.nextInt();
		if (employeeService.validateId(tc)) {
			try {
				if (trainingService.getTrainingById(tc) != null) {
					ArrayList<ParticipantEnrollment> partEnroll = participantService
							.getParticipantEnrollmentByTrainingId(tc);
					if (partEnroll.size() > 0) {
						Iterator<ParticipantEnrollment> it = partEnroll.iterator();
						while (it.hasNext()) {
							System.out.println(it.next());
						}
					} else
						System.out.println("No enrollments.");
				} else
					System.out.println("Training Id does not exist.");

			} catch (FMSException e) {

				e.printStackTrace();
			}
		} else
			System.out.println("Training Id Not Valid");

	}

	private void searchByParticipantId() throws FMSException {
		System.out.println("Enter Participant Id");
		int pid = sc.nextInt();
		if (employeeService.validateId(pid)) {
			try {
				if (employeeService.getEmployeeById(pid) != null) {
					ArrayList<ParticipantEnrollment> partEnroll = participantService
							.getParticipantEnrollmentByParticipantId(pid);
					if (partEnroll.size() > 0) {
						Iterator<ParticipantEnrollment> it = partEnroll.iterator();
						while (it.hasNext()) {
							System.out.println(it.next());
						}
					} else
						System.out.println("No enrollments.");
				} else
					System.out.println("Participant Id does not exist");
			} catch (FMSException e) {

				e.printStackTrace();
			}

		} else
			System.out.println("Partipant Id not valid");
	}

	private void addParticipantEnrollment() throws FMSException {

		System.out.println("Enter the ParticipantId");
		int pid = sc.nextInt();
		if (employeeService.validateId(pid)) {
			if (employeeService.getEmployeeById(pid) != null) {
				// if (true) {
				System.out.println("Enter the Training Code");
				int tc = sc.nextInt();
				if (employeeService.validateId(tc)) {
					if (trainingService.getTrainingById(tc) != null) {
						ParticipantEnrollment partEnroll = new ParticipantEnrollment(tc, pid);
						ParticipantEnrollment Enroll = participantService.addParticipantEnrollment(partEnroll);
						if (Enroll != null)
							System.out.println("Participant Enrolled Successfully");
						else
							System.out.println("Some Problem With Participant Enrollment");
					} else
						System.out.println("Training Code does not exist.");
				} else
					System.out.println("Training Code not valid.");
			} else
				System.out.println("Partipant Id does not exist.");
		} else
			System.out.println("Participant Id not valid");
	}

	private void trainingProgramMaintenance() throws FMSException {
		while (true) {
			System.out.println("\nTraining Program CRUD Operations");
			System.out.println(
					"1.Add Training Program\n2.View Training Program\n3.Delete Training Program\n4.Update Training Program\n5.Search Training Program\n6.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				addTrainingProgram();
				break;
			case 2:
				viewTrainingProgram();
				break;
			case 3:
				deleteTrainingProgram();
				break;
			case 4:
				updateTrainingProgram();
				break;
			case 5:
				searchTrainingProgram();
				break;
			case 6:
				start();
				break;
			default:
				break;

			}
		}

	}

	private void searchTrainingProgram() throws FMSException {

		System.out.println("Enter Training Code");
		int tc = sc.nextInt();
		if (employeeService.validateId(tc)) {
			try {
				Training training = trainingService.getTrainingById(tc);
				if (training != null)
					System.out.println(training);
				else
					System.out.println("No Training Program Found");
			} catch (FMSException e) {

				e.printStackTrace();
			}
		} else
			System.out.println("Training Code not found");

	}

	private void updateTrainingProgram() throws FMSException {

		System.out.println("Enter Training Code");

		int trainingCode = sc.nextInt();
		if (employeeService.validateId(trainingCode)) {
			System.out.println("Enter Course Code");
			int courseCode = sc.nextInt();
			if (employeeService.validateId(courseCode)) {
				System.out.println("Enter Faculty Code");
				int facultyCode = sc.nextInt();
				if (employeeService.validateId(facultyCode)) {
					System.out.println("Enter Start-date in format dd/mm/yyyy format");
					String sd = sc.next();
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate startDate = LocalDate.parse(sd, format);
					System.out.println("Enter End-date in format dd/mm/yyyy format");
					String ed = sc.next();
					LocalDate endDate = LocalDate.parse(ed, format);
					Training training = new Training(trainingCode, courseCode, facultyCode, startDate, endDate);
					Training training1 = trainingService.updateTraining(training);
					if (training1 != null)
						System.out.println("Updated Successfully");
					else
						System.out.println("Some Problem with Update");
				} else
					System.out.println("Faculty Code not valid.");
			} else
				System.out.println("Course code not valid.");
		} else
			System.out.println("Training Code not valid.");
	}

	private void deleteTrainingProgram() throws FMSException {
		System.out.println("Enter Training Code");
		int tc = sc.nextInt();
		if (employeeService.validateId(tc)) {
			if (trainingService.getTrainingById(tc) != null) {
				if (trainingService.deleteTraining(tc))
					System.out.println("Deleted Suceessfully");
				else
					System.out.println("Some Problem with Delete");
			} else
				System.out.println("Training Code does not exist.");
		} else
			System.out.println("Training Code not valid.");

	}

	private void viewTrainingProgram() throws FMSException {
		ArrayList<Training> list2 = new ArrayList<Training>();

		list2 = trainingService.getAllTrainings();

		Iterator<Training> it = list2.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		// System.out.println("It displays the All Training Program Details");

	}

	private void addTrainingProgram() throws FMSException {

		System.out.println("Enter Course Code");
		int courseCode = sc.nextInt();
		if (employeeService.validateId(courseCode)) {
			if (trainingService.getTrainingById(courseCode) != null) {
				System.out.println("Enter Faculty Code");
				int facultyCode = sc.nextInt();
				if (employeeService.validateId(facultyCode)) {
					if (employeeService.getEmployeeById(facultyCode) != null) {
						System.out.println("Enter Startdate in format dd/mm/yyyy format");
						String sd = sc.next();
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						LocalDate startDate = LocalDate.parse(sd, format);
						System.out.println("Enter End date in format dd/mm/yyyy format");
						String ed = sc.next();
						LocalDate endDate = LocalDate.parse(ed, format);

						Training training = new Training(courseCode, facultyCode, startDate, endDate);
						Training training1 = trainingService.addTraining(training);
						if (training1 != null)
							System.out.println("Added Successfully");
						else
							System.out.println("Some Problem with Add");
					}

				} else
					System.out.println("Faculty name not valid");

			}
		} else
			System.out.println("Course Code not valid.");
	}
}
